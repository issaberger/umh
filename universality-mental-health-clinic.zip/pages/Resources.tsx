import React, { useState } from 'react';
import { FileText, Download, ExternalLink, HelpCircle, X, ChevronRight, AlertTriangle, CheckCircle } from 'lucide-react';
import { PHQ9_QUESTIONS, GAD7_QUESTIONS, ASSESSMENT_OPTIONS, PHONE_NUMBER } from '../constants';
import { Link } from 'react-router-dom';

const Resources: React.FC = () => {
  // Assessment State
  const [activeAssessment, setActiveAssessment] = useState<'PHQ9' | 'GAD7' | null>(null);
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<number[]>([]);
  const [showResult, setShowResult] = useState(false);

  const startAssessment = (type: 'PHQ9' | 'GAD7') => {
    setActiveAssessment(type);
    setCurrentStep(0);
    setAnswers([]);
    setShowResult(false);
  };

  const closeAssessment = () => {
    setActiveAssessment(null);
    setCurrentStep(0);
    setAnswers([]);
    setShowResult(false);
  };

  const handleAnswer = (value: number) => {
    const newAnswers = [...answers, value];
    setAnswers(newAnswers);

    const questions = activeAssessment === 'PHQ9' ? PHQ9_QUESTIONS : GAD7_QUESTIONS;
    
    if (currentStep < questions.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      setShowResult(true);
    }
  };

  const calculateScore = () => {
    return answers.reduce((a, b) => a + b, 0);
  };

  const getResult = () => {
    const score = calculateScore();
    if (activeAssessment === 'PHQ9') {
      if (score <= 4) return { level: 'None-Minimal', color: 'text-green-600', bg: 'bg-green-50', desc: "Symptoms are minimal or absent." };
      if (score <= 9) return { level: 'Mild', color: 'text-yellow-600', bg: 'bg-yellow-50', desc: "Mild symptoms of depression." };
      if (score <= 14) return { level: 'Moderate', color: 'text-orange-600', bg: 'bg-orange-50', desc: "Moderate symptoms. A consultation is recommended." };
      if (score <= 19) return { level: 'Moderately Severe', color: 'text-orange-700', bg: 'bg-orange-100', desc: "Symptoms are impacting daily life significantly." };
      return { level: 'Severe', color: 'text-red-700', bg: 'bg-red-50', desc: "Severe symptoms. Professional help is strongly advised." };
    } else {
      // GAD-7
      if (score <= 4) return { level: 'Minimal', color: 'text-green-600', bg: 'bg-green-50', desc: "Anxiety levels are low." };
      if (score <= 9) return { level: 'Mild', color: 'text-yellow-600', bg: 'bg-yellow-50', desc: "Mild anxiety." };
      if (score <= 14) return { level: 'Moderate', color: 'text-orange-600', bg: 'bg-orange-50', desc: "Moderate anxiety. Evaluation recommended." };
      return { level: 'Severe', color: 'text-red-700', bg: 'bg-red-50', desc: "Severe anxiety. Please seek professional support." };
    }
  };

  // Render Modal
  const renderAssessmentModal = () => {
    if (!activeAssessment) return null;
    const questions = activeAssessment === 'PHQ9' ? PHQ9_QUESTIONS : GAD7_QUESTIONS;
    const result = getResult();
    const score = calculateScore();

    return (
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-slate-900/70 backdrop-blur-sm animate-fade-in">
        <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden flex flex-col max-h-[90vh]">
          {/* Header */}
          <div className="bg-primary-50 px-6 py-4 border-b border-primary-100 flex justify-between items-center">
            <h3 className="font-bold text-slate-900 text-lg">
              {activeAssessment === 'PHQ9' ? 'Depression Screening (PHQ-9)' : 'Anxiety Screening (GAD-7)'}
            </h3>
            <button onClick={closeAssessment} className="text-slate-500 hover:text-slate-800 transition-colors">
              <X className="w-6 h-6" />
            </button>
          </div>

          {/* Body */}
          <div className="p-6 overflow-y-auto">
            {!showResult ? (
              <>
                <div className="mb-6">
                   <div className="flex justify-between text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                     <span>Question {currentStep + 1} of {questions.length}</span>
                     <span>{Math.round(((currentStep) / questions.length) * 100)}%</span>
                   </div>
                   <div className="w-full bg-slate-100 rounded-full h-2">
                     <div 
                        className="bg-primary-600 h-2 rounded-full transition-all duration-300" 
                        style={{ width: `${((currentStep) / questions.length) * 100}%` }}
                     ></div>
                   </div>
                </div>
                
                <h4 className="text-xl font-medium text-slate-800 mb-2 leading-relaxed">
                  Over the last 2 weeks, how often have you been bothered by the following problem?
                </h4>
                <p className="text-lg font-bold text-primary-700 mb-8 p-4 bg-primary-50 rounded-lg border border-primary-100">
                  "{questions[currentStep]}"
                </p>

                <div className="space-y-3">
                  {ASSESSMENT_OPTIONS.map((opt) => (
                    <button
                      key={opt.value}
                      onClick={() => handleAnswer(opt.value)}
                      className="w-full text-left px-5 py-4 rounded-xl border border-slate-200 hover:border-primary-500 hover:bg-primary-50 hover:text-primary-800 transition-all font-medium flex justify-between items-center group"
                    >
                      {opt.label}
                      <ChevronRight className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity text-primary-500" />
                    </button>
                  ))}
                </div>
              </>
            ) : (
              <div className="text-center py-4">
                <div className={`inline-flex items-center justify-center p-4 rounded-full mb-6 ${result.bg}`}>
                  {result.level === 'Severe' || result.level === 'Moderately Severe' ? (
                     <AlertTriangle className={`w-10 h-10 ${result.color}`} />
                  ) : (
                     <CheckCircle className={`w-10 h-10 ${result.color}`} />
                  )}
                </div>
                <h4 className="text-sm uppercase tracking-wide text-slate-500 font-bold mb-2">Your Result</h4>
                <div className="text-4xl font-extrabold text-slate-900 mb-2">{score} / {activeAssessment === 'PHQ9' ? 27 : 21}</div>
                <div className={`text-xl font-bold mb-4 ${result.color}`}>{result.level}</div>
                <p className="text-slate-600 mb-8 leading-relaxed max-w-xs mx-auto">
                  {result.desc}
                </p>
                
                <div className="bg-slate-50 p-4 rounded-lg border border-slate-100 text-sm text-slate-500 mb-8 text-left">
                  <strong>Disclaimer:</strong> This screening tool is for informational purposes only and is not a substitute for professional medical advice, diagnosis, or treatment.
                </div>

                <div className="flex flex-col gap-3">
                  <Link 
                    to="/contact" 
                    onClick={closeAssessment}
                    className="w-full bg-primary-600 text-white font-bold py-3 rounded-xl hover:bg-primary-700 transition-colors shadow-md"
                  >
                    Schedule an Appointment
                  </Link>
                   <a 
                    href={`tel:${PHONE_NUMBER.replace(/\D/g,'')}`}
                    className="w-full bg-white text-slate-700 border border-slate-300 font-bold py-3 rounded-xl hover:bg-slate-50 transition-colors"
                  >
                    Call {PHONE_NUMBER}
                  </a>
                   <button 
                    onClick={closeAssessment}
                    className="w-full text-slate-500 font-medium py-2 hover:text-slate-700"
                  >
                    Close
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="animate-fade-in pb-20">
      {renderAssessmentModal()}
      
      <div className="bg-primary-50 py-12 border-b border-primary-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-3xl font-extrabold text-slate-900">Patient Resources</h1>
          <p className="mt-2 text-slate-600">
            Forms, guides, and tools to help you prepare for your visit.
          </p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mt-12 grid grid-cols-1 lg:grid-cols-3 gap-12">
        
        {/* Main Content Area */}
        <div className="lg:col-span-2 space-y-12">
          
          {/* Intake Section */}
          <section>
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-primary-100 rounded-lg">
                <FileText className="w-6 h-6 text-primary-700" />
              </div>
              <h2 className="text-2xl font-bold text-slate-900">New Patient Forms</h2>
            </div>
            <p className="text-slate-600 mb-6">
              To speed up your check-in process, please download and complete the following forms before your first appointment. You can bring them with you or email them to secure@universalityhealth.com.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                "New Patient Intake Packet (Adult)",
                "New Patient Intake Packet (Child/Adolescent)",
                "Release of Information (ROI)",
                "Privacy Policy (HIPAA) Acknowledgment",
                "Telehealth Consent Form"
              ].map((form) => (
                <div key={form} className="flex items-center justify-between p-4 bg-white border border-slate-200 rounded-lg hover:border-primary-300 transition-colors group cursor-pointer shadow-sm">
                  <span className="text-sm font-medium text-slate-700 group-hover:text-primary-700">{form}</span>
                  <Download className="w-4 h-4 text-slate-400 group-hover:text-primary-600" />
                </div>
              ))}
            </div>
          </section>

          {/* Screening Tools */}
          <section>
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-secondary-100 rounded-lg">
                <ExternalLink className="w-6 h-6 text-secondary-700" />
              </div>
              <h2 className="text-2xl font-bold text-slate-900">Self-Screening Tools</h2>
            </div>
            <p className="text-slate-600 mb-6">
              These online assessments can help you determine if you should seek professional help. <em>Note: These are not diagnostic tools.</em>
            </p>
            <ul className="space-y-4">
              <li className="block p-6 bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-bold text-lg text-slate-800">PHQ-9 (Depression Screening)</h3>
                    <p className="text-slate-500 mt-1 mb-4">A 9-question instrument used to screen for depression severity.</p>
                  </div>
                  <span className="bg-blue-100 text-blue-700 text-xs font-bold px-2 py-1 rounded">~3 Mins</span>
                </div>
                <button 
                  onClick={() => startAssessment('PHQ9')}
                  className="inline-flex items-center text-sm font-bold text-white bg-primary-600 px-4 py-2 rounded-lg hover:bg-primary-700 transition-colors"
                >
                  Take Assessment &rarr;
                </button>
              </li>
               <li className="block p-6 bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-all">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-bold text-lg text-slate-800">GAD-7 (Anxiety Screening)</h3>
                    <p className="text-slate-500 mt-1 mb-4">A 7-item scale used to measure generalized anxiety disorder.</p>
                  </div>
                   <span className="bg-blue-100 text-blue-700 text-xs font-bold px-2 py-1 rounded">~2 Mins</span>
                </div>
                <button 
                   onClick={() => startAssessment('GAD7')}
                   className="inline-flex items-center text-sm font-bold text-white bg-primary-600 px-4 py-2 rounded-lg hover:bg-primary-700 transition-colors"
                >
                  Take Assessment &rarr;
                </button>
              </li>
            </ul>
          </section>
        </div>

        {/* Sidebar */}
        <div className="space-y-8">
           <div className="bg-white p-6 rounded-xl shadow-md border border-slate-100">
             <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
               <HelpCircle className="w-5 h-5 text-primary-500" />
               FAQ
             </h3>
             <div className="space-y-4">
               <div>
                 <p className="font-semibold text-sm text-slate-800">Do you accept insurance?</p>
                 <p className="text-sm text-slate-500 mt-1">Yes, we accept Maryland Medicaid, Medicare, and most major private commercial plans (BCBS, United, Cigna, Aetna).</p>
               </div>
               <div>
                 <p className="font-semibold text-sm text-slate-800">What is the cancellation policy?</p>
                 <p className="text-sm text-slate-500 mt-1">Please provide at least 24 hours notice to avoid a cancellation fee.</p>
               </div>
             </div>
           </div>

           <div className="bg-slate-900 text-white p-6 rounded-xl shadow-md">
             <h3 className="text-lg font-bold mb-3">Crisis Support</h3>
             <p className="text-sm text-slate-300 mb-4">
               If you are in immediate danger, call 911 or go to the nearest ER.
             </p>
             <div className="space-y-3">
               <div className="block p-3 bg-slate-800 rounded-lg">
                 <p className="text-xs text-slate-400 uppercase tracking-wider font-bold">Suicide & Crisis Lifeline</p>
                 <p className="text-xl font-bold text-white">988</p>
               </div>
               <div className="block p-3 bg-slate-800 rounded-lg">
                 <p className="text-xs text-slate-400 uppercase tracking-wider font-bold">Crisis Text Line</p>
                 <p className="text-sm font-medium text-white">Text <span className="text-primary-400">HOME</span> to <span className="text-white font-bold">741741</span></p>
               </div>
             </div>
           </div>
        </div>

      </div>
    </div>
  );
};

export default Resources;